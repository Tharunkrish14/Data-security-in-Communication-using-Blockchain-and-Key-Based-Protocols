from flask import Flask, render_template, flash, request, session
from flask import render_template, redirect, url_for, request
#from wtforms import Form, TextField, TextAreaField, validators, StringField, SubmitField
from werkzeug.utils import secure_filename
import urllib.request
import json
import smtplib
#from PIL import Image
import pickle
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import datetime
import os
import plotly.express as px
from sklearn.metrics import classification_report
from sklearn.model_selection import train_test_split, GridSearchCV
from sklearn.neighbors import KNeighborsClassifier
from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
from xgboost import XGBClassifier
from neuralprophet import NeuralProphet
from sklearn.preprocessing import LabelEncoder
df=pd.read_csv("seattle-weather.csv")
df.shape
df.head()
df.describe()
df.info()
# Converting the Dtype on date from object to datetime
df['date'] = pd.to_datetime(df['date'])
df['weather']=LabelEncoder().fit_transform(df['weather'])
df.info()
# Visualizing the temperature, observing if there's abnormal data
plt.figure(figsize = (15, 5))
fig = plt.plot(df['date'], df[['temp_min', 'temp_max']])
plt.grid();
plt.figure(figsize = (15, 5))
fig2 = plt.plot(df['date'], df[['precipitation', 'wind']])
plt.grid();
df['month'] = df['date'].dt.month_name(locale='English')

fig = px.box(df, df.month, ['temp_min', 'temp_max'])
fig.update_layout(title='Warmest and Coldest Monthly Tempratue.')
#fig.show()
df[["precipitation","temp_max","temp_min","wind"]].corr()
plt.figure(figsize=(12,7))
sns.heatmap(df[["precipitation","temp_max","temp_min","wind"]].corr(),annot=True,cmap='coolwarm');
features=["precipitation", "temp_max", "temp_min", "wind"]
X=df[features]
y=df.weather
X_train, X_test, y_train,y_test = train_test_split(X, y,random_state = 0)
xgb = XGBClassifier()
xgb.fit(X_train,y_train)
print("XGB Accuracy:{:.2f}%".format(xgb.score(X_test,y_test)*100))
knn = KNeighborsClassifier()
knn.fit(X_train,y_train)
print("KNN Accuracy:{:.2f}%".format(knn.score(X_test,y_test)*100))
ab = AdaBoostClassifier()
ab.fit(X_train, y_train)
print("AB Accuracy:{:.2f}%".format(ab.score(X_test,y_test)*100))
ab.get_params().keys()
parameters = {
    'learning_rate': [1, 2, 3],
    'n_estimators': [100, 500, 1000]
}










app = Flask(__name__)
app.config.from_object(__name__)
app.config['SECRET_KEY'] = '7d441f27d441f27567d441f2b6176a'

app.config['DEBUG']


@app.route("/")
def homepage():
    return render_template('index.html')

@app.route("/uploaddata")
def uploaddata():
    return render_template('uploaddata.html')
@ app.route('/udata', methods=['POST'])
def udata():

    if request.method == 'POST':
        file = request.files.get('file')
        import numpy as np
        import pandas as pd
        import matplotlib.pyplot as plt
        import seaborn as sns
        import datetime
        import os
        import plotly.express as px
        from sklearn.metrics import classification_report
        from sklearn.model_selection import train_test_split, GridSearchCV
        from sklearn.neighbors import KNeighborsClassifier
        from sklearn.ensemble import RandomForestClassifier, AdaBoostClassifier
        from xgboost import XGBClassifier
        from neuralprophet import NeuralProphet
        from sklearn.preprocessing import LabelEncoder
        df = pd.read_csv("seattle-weather.csv")
        df.shape
        df.head()
        df.describe()
        df.info()
        # Converting the Dtype on date from object to datetime
        df['date'] = pd.to_datetime(df['date'])
        df['weather'] = LabelEncoder().fit_transform(df['weather'])
        df.info()
        # Visualizing the temperature, observing if there's abnormal data
        plt.figure(figsize=(15, 5))
        fig = plt.plot(df['date'], df[['temp_min', 'temp_max']])
        plt.grid();
        plt.figure(figsize=(15, 5))
        fig2 = plt.plot(df['date'], df[['precipitation', 'wind']])
        plt.grid();
        df['month'] = df['date'].dt.month_name(locale='English')

        fig = px.box(df, df.month, ['temp_min', 'temp_max'])
        fig.update_layout(title='Warmest and Coldest Monthly Tempratue.')
        #fig.show()
        df[["precipitation", "temp_max", "temp_min", "wind"]].corr()
        plt.figure(figsize=(12, 7))
        sns.heatmap(df[["precipitation", "temp_max", "temp_min", "wind"]].corr(), annot=True, cmap='coolwarm');
        features = ["precipitation", "temp_max", "temp_min", "wind"]
        X = df[features]
        y = df.weather
        X_train, X_test, y_train, y_test = train_test_split(X, y, random_state=0)
        ab = AdaBoostClassifier()
        ab.fit(X_train, y_train)
        print("AB Accuracy:{:.2f}%".format(ab.score(X_test, y_test) * 100))

        file_extension = file.filename.split('.')[1]
        print(file_extension)
        # file.save("static/upload/" + secure_filename(file.filename))

        import pandas as pd
        import matplotlib.pyplot as plt
        df = ''
        if file_extension == 'xlsx':
            df = pd.read_excel(file.read(), engine='openpyxl')
        elif file_extension == 'xls':
            df = pd.read_excel(file.read())
        elif file_extension == 'csv':
            df = pd.read_csv(file)

        print(df)

        import seaborn as sns
        sns.countplot(df['weather'].value_counts(), label="count")
        plt.savefig('static/image/out.jpg')
        iimg = 'static/image/out.jpg'
        return render_template('ViewExcel.html', data=df.to_html(), dataimg=iimg)

@app.route("/prediction")
def prediction():

    return render_template('prediction.html',)
@app.route('/pdata', methods=['POST'])
def pdata():


    if request.method == 'POST':
        p = float(request.form['p'])
        tm = float(request.form['tm'])
        tmm = float(request.form['tmm'])
        w = float(request.form['w'])
        input = [[p, tm, tmm, w]]
        ot = ab.predict(input)
        print("The weather is:")
        if (ot == 0):
            r="Drizzle"
            print("Drizzle")
        elif (ot == 1):
            r="Fog"
            print("Fog")
        elif (ot == 2):
            r="Rain"
            print("Rain")
        elif (ot == 3):
            r="snow"
            print("snow")
        else:
            print("Sun")
        import requests
        import calendar

        api_key = '9d7cde1f6d07ec55650544be1631307e'
        api_call = 'https://api.openweathermap.org/data/2.5/forecast?appid=9d7cde1f6d07ec55650544be1631307e'
        api_call += '&q=trichy'
        i = 0
        if i == 0:
            json_data = requests.get(api_call).json()

            location_data = {
                'city': json_data['city']['name'],
                'country': json_data['city']['country']
            }

            print('\n{city}, {country}'.format(**location_data))

            # The current date we are iterating through
            current_date = ''

            # Iterates through the array of dictionaries named list in json_data
            for item in json_data['list']:

                # Time of the weather data received, partitioned into 3 hour blocks
                time = item['dt_txt']

                # Split the time into date and hour [2018-04-15 06:00:00]
                next_date, hour = time.split(' ')

                # Stores the current date and prints it once
                if current_date != next_date:
                    current_date = next_date
                    year, month, day = current_date.split('-')
                    date = {'y': year, 'm': month, 'd': day}
                    print('\n{m}/{d}/{y}'.format(**date))

                # Grabs the first 2 integers from our HH:MM:SS string to get the hours
                hour = int(hour[:2])

                # Sets the AM (ante meridiem) or PM (post meridiem) period
                if hour < 12:
                    if hour == 0:
                        hour = 12
                    meridiem = 'AM'
                else:
                    if hour > 12:
                        hour -= 12
                    meridiem = 'PM'

                # Prints the hours [HH:MM AM/PM]
                print('\n%i:00 %s' % (hour, meridiem))

                # Temperature is measured in Kelvin
                temperature = item['main']['temp']

                # Weather condition
                description = item['weather'][0]['description'],

                # Prints the description as well as the temperature in Celcius and Farenheit
                print('Weather condition: %s' % description)
                print('Celcius: {:.2f}'.format(temperature - 273.15))
                print('Farenheit: %.2f' % (temperature * 9 / 5 - 459.67))

            # Prints a calendar of the current month
            calendar = calendar.month(int(year), int(month))
            print('\n' + calendar)

            # Asks the user if he/she wants to exit

        return render_template('prediction1.html',p=p,tm=tm,tmm=tmm,w=w,result=r)
@app.route("/analysis")
def analysis():
    return render_template('analysis.html')
@app.route("/realtime")
def realtime():
    return render_template('realtime.html',data='')


@app.route('/city', methods=['POST', 'GET'])
def city():
    if request.method == 'POST':
        import requests
        city = request.form['city']
    else:
        # for default name mathura
        city = 'mathura'

    # your API key will come here
    api = '9d7cde1f6d07ec55650544be1631307e'

    # source contain json data from api
    source ='https://api.openweathermap.org/data/2.5/weather?q='+city+'&appid=9d7cde1f6d07ec55650544be1631307e'
    r = requests.get(source).json()

    # converting JSON data to a dictionary
    list_of_data = r
    print(list_of_data)

    # data for variable list_of_data
    data = {

        "temp_min": str(list_of_data['main']['temp_min']) + 'k',
        "temp_max": str(list_of_data['main']['temp_max']) + 'k',
        "pressure": str(list_of_data['main']['pressure']),
        "humidity": str(list_of_data['main']['humidity']),

        "wind_spped": str(list_of_data['wind']['speed'])
    }
    print(data)
    return render_template('realtime.html', data=data)

@app.route("/fst", methods=["GET", "POST"])
def home():
    city_name=''
    five_day_temp_list=[]
    five_day_weather_list=[]
    # Define a dictionary containing employee data
    df = pd.read_csv("seattle-weather.csv",usecols = ['temp_max','weather'])

    # Convert the dictionary into DataFrame
    df= pd.DataFrame(df)

    # Select one row randomly using sample()
    # without give any parameters
    df = pd.DataFrame(df)

    # Select one row randomly using sample()
    # without give any parameters
    df = df.sample(n=5)

    for item, row in df.iterrows():
        print(row['temp_max'])
        five_day_temp_list.append(row['temp_max'])
        five_day_weather_list.append(row['weather'])

    import datetime
    base = datetime.datetime.today()
    current_date=base.strftime('%Y-%m-%d')
    print(base.strftime('%Y-%m-%d'))
    current_temp=30.2
    five_day_dates_list = []
    current_weather='rain'
    min_temp=20.3
    max_temp=30.2
    wind_speed=30.34

    import calendar
    from datetime import date, timedelta

    today = date.today()

    for x in range(1, 6):
        s = base + datetime.timedelta(days=x)
        m=today + timedelta(days=x)
        d=calendar.day_name[m.weekday()]
        five_day_dates_list.append(d)

        print(base + datetime.timedelta(days=x))
    print(five_day_temp_list)
    print(five_day_temp_list)

    return render_template("city.html", city_name=city_name, current_date=current_date, current_temp=current_temp,
                           current_weather=current_weather, min_temp=min_temp, max_temp=max_temp, wind_speed=wind_speed,
                           five_day_temp_list=five_day_temp_list, five_day_weather_list=five_day_weather_list,
                           five_day_dates_list=five_day_dates_list)

if __name__ == '__main__':
    app.run(debug=True, use_reloader=True)